#include <iostream>
using namespace std;
int main()
{int sum,sub,mul,div,a,b;
a=10,b=5;
sum=a+b,sub=a-b,mul=a*b,div=a/b;
cout<<sum<<"\n";
cout<<sub<<"\n";
cout<<mul<<"\n";
cout<<div;
return 0;
}
