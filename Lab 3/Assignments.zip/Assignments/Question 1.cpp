#include<iostream>
using namespace std;
int main()
{
	int num1,num2;
	cout<<"enter num1 and num2="<<endl;
	cin>>num1>>num2;
	
	cout<<"num1+num2="<<num1+num2<<endl;
	cout<<"num1-num2="<<num1-num2<<endl;
	cout<<"num1*num2="<<num1*num2<<endl;
	cout<<"num1/num2="<<num1/num2<<endl;
	cout<<"num1%num2="<<num1%num2;
	
	return 0;
}
