#include<iostream>
#include<iomanip>
using namespace std;
int main()
{
	int a;
	cout<<"Enter the value of a= ";
	cin>>a;
	
	cout<<a<<"*1"<<"="<<a*1<<setw(1)<<endl;
	cout<<a<<"*2"<<"="<<a*2<<setw(1)<<endl;
	cout<<a<<"*3"<<"="<<a*3<<setw(1)<<endl;
	cout<<a<<"*4"<<"="<<a*4<<setw(1)<<endl;
	cout<<a<<"*5"<<"="<<a*5<<setw(1)<<endl;
	cout<<a<<"*6"<<"="<<a*6<<setw(1)<<endl;
	cout<<a<<"*7"<<"="<<a*7<<setw(1)<<endl;
	cout<<a<<"*8"<<"="<<a*8<<setw(1)<<endl;
	cout<<a<<"*9"<<"="<<a*9<<setw(1)<<endl;
	cout<<a<<"*10"<<"="<<a*10<<setw(1);
	
	return 0;
}
