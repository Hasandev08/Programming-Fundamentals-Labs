#include<iostream>
using namespace std;
int main()
{
	int op,mp,str,sp,fp;
	
	op=100;
	cout<<"op="<<op<<endl;
	
	mp=0.25*100;
	cout<<"mp="<<mp<<endl;
	
	str=0.25*100;
	cout<<"str="<<str<<endl;
	
	sp=120;
	cout<<"sp="<<sp<<endl;
	
	fp=sp+str;
	cout<<fp;
	
	return 0;
}
