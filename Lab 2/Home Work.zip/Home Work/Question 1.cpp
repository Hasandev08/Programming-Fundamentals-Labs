#include<iostream>
using namespace std;
int main()

{
	int a,b;
	
	a=30,b=20;
	
	cout<<"Before swapping\n"<<endl;
	cout<<"a="<<a<<" b="<<b<<endl;
	
	cout<<"After swapping\n"<<endl;
	cout<<"a="<<b<<" b="<<a<<endl;
	
	return 0;
}
