#include<iostream>
using namespace std;
int main()
{
char ch;

cout<<"enter any character"<<ch<<endl;
cin>>ch;

ch++;

cout<<"enter next character\n"<<ch<<endl;

return 0;
}
