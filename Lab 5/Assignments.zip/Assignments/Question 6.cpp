#include<iostream>

using namespace std;
int main()
{
	int i,j;
	
	while(i<=6)
	{
		j=1;
		
		while(j<=i)
		{
			cout<<"*";
			j++;
		}
		cout<<endl;
		i++;
	}
	return 0;
	
}
