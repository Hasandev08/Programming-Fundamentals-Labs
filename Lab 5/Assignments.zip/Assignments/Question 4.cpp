#include<iostream>

using namespace std;
int main()
{
	int i,j,p,sum,a;
	
	sum=0;
	
	cout<<"Enter the value= "<<endl;
	cin>>a;
	
	for(i=2;i<=a;i++)
	{
		p=1;
		j=2;
		
		for(;j<i;)
		{
			if(i%j==0)
			{
				p=0;
				break;
			}
			
			j++;
		}
		
		if(p==1)
		{
			sum=sum+j;
		}
	}
	
	cout<<"Sum= "<<sum;
	
	return 0;
}
